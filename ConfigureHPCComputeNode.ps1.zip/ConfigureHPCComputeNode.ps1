configuration ConfigureHPCComputeNode
{
    Param
    (
        [Parameter(Mandatory = $false)][System.Collections.HashTable]$ScriptOptions
    )

    Node localhost
    {
        Script ConfigureComputeNode
        {
            GetScript = {
                return @{ Result = $true }
            }

            SetScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $HPCHeadNode = '{HPCHeadNode}';

                Write-Verbose "Configure HPC Compute Node";
                Invoke-Command -ComputerName localhost -FilePath "$($env:CCP_HOME)\Bin\Set-HpcClusterName.ps1" -ArgumentList "-ClusterName $($HPCHeadNode)" | Write-Verbose;
            }

            TestScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $HPCHeadNode = '{HPCHeadNode}';

                $HPCKeyPath = "HKLM:\SOFTWARE\Microsoft\HPC";

                if (Test-Path -Path $HPCKeyPath)
                {
                    $ClusterName = Get-ItemProperty -Name ClusterName -LiteralPath $HPCKeyPath -ErrorAction SilentlyContinue;
                    if ($ClusterName.ClusterName -ne $HPCHeadNode)
                    {
                        Write-Verbose "Current clustername $($ClusterName.ClusterName) is different than the specified $($HPCHeadNode)";
                        Return $false;
                    }
                    else
                    {
                        Write-Verbose "Current clustername $($ClusterName.ClusterName) is equal with the specified $($HPCHeadNode)";
                        Return $true;
                    }
                }
                else
                {
                    Write-Verbose "No clustername configured";
                    Return $false;
                }
            }
        }
    }
}

function Format-DscScriptBlock()
{
    param(
        [Parameter(Mandatory=$True)][System.Collections.HashTable]$Data,
        [Parameter(Mandatory=$True)][System.Management.Automation.ScriptBlock]$ScriptBlock
    )
    
    $Result = $ScriptBlock.ToString();
    foreach ($Key in $Data.Keys)
    {
        $Result = $Result.Replace("{$Key}", $Data[$Key]);
    }
    return $Result;
}
