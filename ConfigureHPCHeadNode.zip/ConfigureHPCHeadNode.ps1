configuration ConfigureHPCHeadNode
{
    Param
    (
        [Parameter(Mandatory = $false)][System.Collections.HashTable]$ScriptOptions
    )

    Node localhost
    {
        Script ConfigureHeadNode
        {
            GetScript = {
                return @{ Result = $true }
            }

            SetScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $SqlServer = ".\ComputeCluster";
                
                # BitLocker load to high for configuring services
                while ((Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1") -ne $Null)
                {
                    Write-Verbose "Waiting on BitLocker to complete $([System.DateTime]::Now)";
                    Start-Sleep -Seconds 60;
                }
                
                if ($SqlServer -eq '.\ComputeCluster')
                {
                    Write-Verbose "Starting SQL Server Services";
                    $SQLServices = @('MSSQL$COMPUTECLUSTER', 'SQLBrowser', 'SQLWriter');
                    $SQLServices | Set-Service -StartupType Automatic -Verbose | Write-Verbose;
                    Start-Sleep -Seconds 1;
                    for ($i = 0; $i -lt 10; $i++)
                    {
                        # Create a loop to start the SQL Services
                        foreach ($SQLService in $SQLServices)
                        {
                            if ((Get-Service -Name $SQLService).Status -eq 'Stopped')
                            {
                                # Start services that are stopped
                                Start-Service -Name $SQLService;
                            }
                        }
                        Start-Sleep -Seconds 1;
                        # Check if all services are running
                        if (($SQLServices | Get-Service | Where-Object -FilterScript {$_.Status -ne 'Running'}) -ne $Null)
                        {
                            # Wait 5 seconds before rerunning the loop
                            Start-Sleep -Seconds 5;
                        }
                        else
                        {
                            # Exit the loop
                            break;
                        }
                    }
                    
                    <#
                    # Add depency on local MSSQL service
                    $HpcSdm = Get-Service -Name 'HpcSdm';
                    if (!$HpcSdm.ServicesDependedOn.Name.Contains('MSSQL$COMPUTECLUSTER'))
                    {
                        $HpcSdmWmi = Get-WmiObject -Class Win32_Service -Filter "Name='HpcSdm'";
                        $DependsOnServices = @('MSSQL$COMPUTECLUSTER');
                        ($HpcSdm.ServicesDependedOn | Select-Object -ExpandProperty Name) | foreach { $DependsOnServices += $_.ToString(); };
                        $Result = $HpcSdmWmi.Change($Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$DependsOnServices);
                        if ($Result.ReturnValue -eq 0)
                        {
                            Write-Verbose "Added depency of MSSQL`$COMPUTECLUSTER for service HpcSdm";
                        }
                        else
                        {
                            Write-Verbose "Failed to add depency of MSSQL`$COMPUTECLUSTER for service HpcSdm";
                        }
                    }
                    #>
                }
                
                Write-Verbose "Configure HPC Head Node";
                Invoke-Command -ComputerName localhost -FilePath "$($env:CCP_HOME)\Bin\HPCHNPrepare.ps1" -ArgumentList $SqlServer | Write-Verbose;
            }

            TestScript = {
                $Service = Get-WmiObject -Class Win32_Service -Filter 'name = "HpcSdm"';
                if ($Service -eq $Null)
                {
                    Write-Verbose "HPC SDM Store Service service is not found";
                    Return $false;
                }
                else
                {
                    if ($Service.StartMode -ne 'Auto')
                    {
                        Write-Verbose "Service $($Service.Name) is configured with start mode $($Service.StartMode) instead of auto";
                        Return $false;
                    }
                    else
                    {
                        Write-Verbose "Service $($Service.Name) is configured correctly";
                        Return $true;
                    }
                }
            }
        }

        Script ConfigureHeadNodeParameters
        {
            GetScript = {
                return @{ Result = $true }
            }

            SetScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $ServiceAccount = '{ServiceAccount}';
                $ServiceAccountPassword = "{ServiceAccountPassword}";
                $NodeNamingSeries = "{NodeNamingSeries}";

                Add-PSSnapIn Microsoft.HPC;
                Write-Verbose "Configure HPC Head Node";

                if (!(Get-HpcNetworkTopology -ErrorAction SilentlyContinue))
                {
                    Write-Verbose "Configure network";
                    $Adapter = Get-NetAdapter -Physical;
                    Set-HpcNetwork -Topology Enterprise -Enterprise $Adapter.InterfaceDescription -EnterpriseFirewall:$true;
                }

                $HPCProperties = Get-HpcClusterProperty;
                $InstallCredential = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'InstallCredential'};
                if ($InstallCredential.Value -eq $Null)
                {
                    Write-Verbose "Configure install credential";
                    $Credential = New-Object System.Management.Automation.PSCredential($ServiceAccount,(ConvertTo-SecureString -String $ServiceAccountPassword -AsPlainText -Force));
                    Set-HpcClusterProperty -InstallCredential $Credential;
                }

                $NodeNaming = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'NodeNamingSeries'};
                if ($NodeNaming.Value -eq $Null)
                {
                    Write-Verbose "Configure node naming series";
                    Set-HpcClusterProperty -NodeNamingSeries $NodeNamingSeries;
                }

                $NodeTemplate = Get-HpcNodeTemplate | Where-Object -FilterScript {$_.Name -eq 'ComputeNode Template'};
                if ($NodeTemplate -eq $Null)
                {
                    Write-Verbose "Add compute node template";
                    $Template = New-HpcNodeTemplate -Name 'ComputeNode Template' -Description 'ComputeNode Template Created by DSC' -Type ComputeNode;
                }

            }
            
            TestScript = {
                Add-PSSnapIn Microsoft.HPC;

                if (!(Get-HpcNetworkTopology -ErrorAction SilentlyContinue))
                {
                    Write-Verbose "HPC Network Toplogy not configured";
                    Return $false;
                }
                $HPCProperties = Get-HpcClusterProperty;
                $InstallCredential = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'InstallCredential'};
                if ($InstallCredential.Value -eq $Null)
                {
                    Write-Verbose "HPC Installation Credential not configured";
                    Return $false;
                }
                $NodeNaming = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'NodeNamingSeries'};
                if ($NodeNaming.Value -eq $Null)
                {
                    Write-Verbose "HPC Node Naming Series not configured";
                    Return $false;
                }
                $NodeTemplate = Get-HpcNodeTemplate | Where-Object -FilterScript {$_.Name -eq 'ComputeNode Template'};
                if ($NodeTemplate -eq $Null)
                {
                    Write-Verbose "No HPC Compute Node Template found";
                    Return $false;
                }

                Return $true;
            }

            DependsOn = "[Script]ConfigureHeadNode"
        }
    }
}

function Format-DscScriptBlock()
{
    param(
        [Parameter(Mandatory=$True)][System.Collections.HashTable]$Data,
        [Parameter(Mandatory=$True)][System.Management.Automation.ScriptBlock]$ScriptBlock
    )
    
    $Result = $ScriptBlock.ToString();
    foreach ($Key in $Data.Keys)
    {
        $Result = $Result.Replace("{$Key}", $Data[$Key]);
    }
    return $Result;
}
