﻿configuration ConfigSQLServer 
{ 
   param 
   ( 
        [String]$SQLInstanceName = "MSSQLSERVER",

        [System.Management.Automation.PSCredential]$LoginCredential,

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xSQLServer, xNetworking
    if($SQLInstanceName -eq "MSSQLSERVER")
    {
        $sqlService = "MSSQLSERVER"
    }
    else
    {
        $sqlService = "MSSQL`$$SQLInstanceName"
    }

    $isMixedMode = $PSBoundParameters.ContainsKey('LoginCredential')

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        xFirewall SQLServerTCPIn
        {
            Name = "sqlservice-tcp-in"
            DisplayName = "Allow SQL Server TCP In"
            Ensure = "Present"
            Action = "Allow"
            Direction = "Inbound"
            Protocol = "TCP"
            Service = $sqlService
        }

        cSQLServerDatabase HPCManagementDB
        {
            Database = 'HPCManagement'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
        }

        cSQLServerDatabase HPCSchedulerDB
        {
            Database = 'HPCScheduler'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 50
        }

        cSQLServerDatabase HPCReportingDB
        {
            Database = 'HPCReporting'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
        }

        cSQLServerDatabase HPCDiagnosticsDB
        {
            Database = 'HPCDiagnostics'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            DataFileSizeInMB = 256
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
        }

        cSQLServerDatabase HPCMonitoringDB
        {
            Database = 'HPCMonitoring'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            DataFileSizeInMB = 512
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
        }

        if($isMixedMode)
        {
            cSQLServerLoginMode SetMixedLoginMode
            {
                SQLInstanceName = $SQLInstanceName
                LoginMode = "Mixed"
                DependsOn = "[cSQLServerDatabase]HPCManagementDB","[cSQLServerDatabase]HPCSchedulerDB","[cSQLServerDatabase]HPCReportingDB","[cSQLServerDatabase]HPCDiagnosticsDB","[cSQLServerDatabase]HPCMonitoringDB"
            }

            xSQLServerLogin AddSQLServerLogin
            {
                Ensure = "Present"
                Name = $LoginCredential.UserName
                LoginType = "SqlLogin"
                LoginCredential = $LoginCredential
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[cSQLServerLoginMode]SetMixedLoginMode"
            }

            xSQLServerRoleMembership AddSysadminForLogin
            {
                Ensure = "Present"
                RoleName = "sysadmin"
                Login = $LoginCredential.UserName
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLogin"
            }
        }
    }
} 

