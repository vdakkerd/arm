configuration ConfigureHPCHeadNode
{
    Param
    (
        [Parameter(Mandatory = $false)][System.Collections.HashTable]$ScriptOptions
    )

    Node localhost
    {
        Script ConfigureHeadNode
        {
            GetScript = {
                return @{ Result = $true }
            }

            SetScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $SqlServer = ".\ComputeCluster";
                
                # BitLocker load to high for configuring services
                Write-Verbose "$([System.DateTime]::Now) Checking for BitLocker volume encryption in progress";
                foreach ($Volume in (Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1"))
                {
                    Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) in progress";
                    $Result = $Volume.PauseConversion();
                    if ($Result.ReturnValue -eq 0)
                    {
                        Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) paused";
                    }
                    else
                    {
                        Write-Verbose "$([System.DateTime]::Now) Failed to pause encryption of volume $($Volume.DriveLetter)";
                    }
                }
                <#
                while ((Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1") -ne $Null)
                {
                    Write-Verbose "Waiting on BitLocker to complete $([System.DateTime]::Now)";
                    Start-Sleep -Seconds 60;
                }
                #>
                if ($SqlServer -eq '.\ComputeCluster')
                {
                    Write-Verbose "Starting SQL Server Services";
                    $SQLServices = @('MSSQL$COMPUTECLUSTER', 'SQLBrowser', 'SQLWriter');
                    $SQLServices | Set-Service -StartupType Automatic -Verbose | Write-Verbose;
                    Start-Sleep -Seconds 1;
                    for ($i = 0; $i -lt 10; $i++)
                    {
                        # Create a loop to start the SQL Services
                        foreach ($SQLService in $SQLServices)
                        {
                            if ((Get-Service -Name $SQLService).Status -eq 'Stopped')
                            {
                                # Start services that are stopped
                                Start-Service -Name $SQLService -ErrorAction SilentlyContinue;
                            }
                        }
                        Start-Sleep -Seconds 1;
                        # Check if all services are running
                        if (($SQLServices | Get-Service | Where-Object -FilterScript {$_.Status -ne 'Running'}) -ne $Null)
                        {
                            # Wait 5 seconds before rerunning the loop
                            Start-Sleep -Seconds 5;
                        }
                        else
                        {
                            # Exit the loop
                            break;
                        }
                    }
                    
                    <#
                    # Add depency on local MSSQL service
                    $HpcSdm = Get-Service -Name 'HpcSdm';
                    if (!$HpcSdm.ServicesDependedOn.Name.Contains('MSSQL$COMPUTECLUSTER'))
                    {
                        $HpcSdmWmi = Get-WmiObject -Class Win32_Service -Filter "Name='HpcSdm'";
                        $DependsOnServices = @('MSSQL$COMPUTECLUSTER');
                        ($HpcSdm.ServicesDependedOn | Select-Object -ExpandProperty Name) | foreach { $DependsOnServices += $_.ToString(); };
                        $Result = $HpcSdmWmi.Change($Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$Null,$DependsOnServices);
                        if ($Result.ReturnValue -eq 0)
                        {
                            Write-Verbose "Added depency of MSSQL`$COMPUTECLUSTER for service HpcSdm";
                        }
                        else
                        {
                            Write-Verbose "Failed to add depency of MSSQL`$COMPUTECLUSTER for service HpcSdm";
                        }
                    }
                    #>
                }
                
                Write-Verbose "$([System.DateTime]::Now) Configure HPC Head Node";
                Invoke-Command -ComputerName localhost -FilePath "$($env:CCP_HOME)\Bin\HPCHNPrepare.ps1" -ArgumentList $SqlServer | Write-Verbose;
                
                # BitLocker load to high for configuring services
                Write-Verbose "$([System.DateTime]::Now) Checking for paused BitLocker volume encryption";
                foreach ($Volume in (Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1 and ConversionStatus = 4"))
                {
                    Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) is paused";
                    $Result = $Volume.ResumeConversion();
                    if ($Result.ReturnValue -eq 0)
                    {
                        Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) resumed";
                    }
                    else
                    {
                        Write-Verbose "$([System.DateTime]::Now) Failed to resume encryption of volume $($Volume.DriveLetter)";
                    }
                }
            }

            TestScript = {
                $Service = Get-WmiObject -Class Win32_Service -Filter 'name = "HpcSdm"';
                if ($Service -eq $Null)
                {
                    Write-Verbose "HPC SDM Store Service service is not found";
                    Return $false;
                }
                else
                {
                    if ($Service.StartMode -ne 'Auto')
                    {
                        Write-Verbose "Service $($Service.Name) is configured with start mode $($Service.StartMode) instead of auto";
                        Return $false;
                    }
                    else
                    {
                        Write-Verbose "Service $($Service.Name) is configured correctly";
                        Return $true;
                    }
                }
            }
        }

        Script ConfigureHeadNodeParameters
        {
            GetScript = {
                return @{ Result = $true }
            }

            SetScript = Format-DscScriptBlock -Data $ScriptOptions -ScriptBlock {
                $ServiceAccount = '{ServiceAccount}';
                $ServiceAccountPassword = "{ServiceAccountPassword}";
                $NodeNamingSeries = "{NodeNamingSeries}";

                # BitLocker load to high for configuring services
                Write-Verbose "$([System.DateTime]::Now) Checking for BitLocker volume encryption in progress";
                foreach ($Volume in (Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1"))
                {
                    Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) in progress";
                    $Result = $Volume.PauseConversion();
                    if ($Result.ReturnValue -eq 0)
                    {
                        Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) paused";
                    }
                    else
                    {
                        Write-Verbose "$([System.DateTime]::Now) Failed to pause encryption of volume $($Volume.DriveLetter)";
                    }
                }

                Add-PSSnapIn Microsoft.HPC;
                Write-Verbose "Configure HPC Head Node";

                if (!(Get-HpcNetworkTopology -ErrorAction SilentlyContinue))
                {
                    Write-Verbose "Configure network";
                    $Adapter = Get-NetAdapter -Physical;
                    $Retry = 0;
                    while ($true)
                    {
                        try
                        {
                            Set-HpcNetwork -Topology Enterprise -Enterprise $Adapter.InterfaceDescription -EnterpriseFirewall:$true -ErrorAction Stop | Out-Null;
                            break;
                        }
                        catch
                        {
                            if ($Retry -lt 10)
                            {
                                Write-Verbose "Failed to set Hpc network topology, maybe the head node is still on initialization";
                                Start-Sleep -Seconds 10;
                                $Retry++;
                            }
                            else
                            {
                                throw;
                            }
                        }
                    }
                    
                }

                $HPCProperties = Get-HpcClusterProperty;
                $InstallCredential = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'InstallCredential'};
                if ($InstallCredential.Value -eq $Null)
                {
                    Write-Verbose "Configure install credential";
                    [System.Void][System.Reflection.Assembly]::LoadWithPartialName('System.DirectoryServices.AccountManagement');
                    if ($ServiceAccount.Contains('@'))
                    {
                        $Account = [System.DirectoryServices.AccountManagement.Principal]::FindByIdentity([System.DirectoryServices.AccountManagement.PrincipalContext]::new([System.DirectoryServices.AccountManagement.ContextType]::Domain),[System.DirectoryServices.AccountManagement.IdentityType]::UserPrincipalName,$ServiceAccount);
                    }
                    else
                    {
                        $Account = [System.DirectoryServices.AccountManagement.Principal]::FindByIdentity([System.DirectoryServices.AccountManagement.PrincipalContext]::new([System.DirectoryServices.AccountManagement.ContextType]::Domain),[System.DirectoryServices.AccountManagement.IdentityType]::SamAccountName,$ServiceAccount.Split('\')[1]);
                    }
                    
                    if ($Account -eq $Null)
                    {
                        Write-Verbose "Account $($ServiceAccount) couldn't be found";
                    }
                    else
                    {
                        Write-Verbose "Found account name $($Account.SamAccountName) with UPN $($Account.UserPrincipalName)";
                    }
                    
                    $Credential = New-Object System.Management.Automation.PSCredential($ServiceAccount,(ConvertTo-SecureString -String $ServiceAccountPassword -AsPlainText -Force));
                    Set-HpcClusterProperty -InstallCredential $Credential -ErrorAction SilentlyContinue;
                }

                $NodeNaming = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'NodeNamingSeries'};
                if ($NodeNaming.Value -eq $Null)
                {
                    Write-Verbose "Configure node naming series";
                    Set-HpcClusterProperty -NodeNamingSeries $NodeNamingSeries -ErrorAction SilentlyContinue;
                }

                $NodeTemplate = Get-HpcNodeTemplate | Where-Object -FilterScript {$_.Name -eq 'Default ComputeNode Template'};
                if ($NodeTemplate -eq $Null)
                {
                    Write-Verbose "Add compute node template";
                    $Template = New-HpcNodeTemplate -Name 'Default ComputeNode Template' -Description 'This is the default compute node template' -Type ComputeNode -ErrorAction SilentlyContinue;
                }

                # BitLocker load to high for configuring services
                Write-Verbose "$([System.DateTime]::Now) Checking for paused BitLocker volume encryption";
                foreach ($Volume in (Get-WmiObject -Class Win32_EncryptableVolume  -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -Filter "IsVolumeInitializedForProtection=true and not ProtectionStatus = 1 and ConversionStatus = 4"))
                {
                    Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) is paused";
                    $Result = $Volume.ResumeConversion();
                    if ($Result.ReturnValue -eq 0)
                    {
                        Write-Verbose "$([System.DateTime]::Now) Encryption of volume $($Volume.DriveLetter) resumed";
                    }
                    else
                    {
                        Write-Verbose "$([System.DateTime]::Now) Failed to resume encryption of volume $($Volume.DriveLetter)";
                    }
                }
            }
            
            TestScript = {
                Add-PSSnapIn Microsoft.HPC;

                if (!(Get-HpcNetworkTopology -ErrorAction SilentlyContinue))
                {
                    Write-Verbose "HPC Network Toplogy not configured";
                    Return $false;
                }
                $HPCProperties = Get-HpcClusterProperty;
                $InstallCredential = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'InstallCredential'};
                if ($InstallCredential.Value -eq $Null)
                {
                    Write-Verbose "HPC Installation Credential not configured";
                    Return $false;
                }
                $NodeNaming = $HPCProperties | Where-Object -FilterScript {$_.Name -eq 'NodeNamingSeries'};
                if ($NodeNaming.Value -eq $Null)
                {
                    Write-Verbose "HPC Node Naming Series not configured";
                    Return $false;
                }
                $NodeTemplate = Get-HpcNodeTemplate | Where-Object -FilterScript {$_.Name -eq 'ComputeNode Template'};
                if ($NodeTemplate -eq $Null)
                {
                    Write-Verbose "No HPC Compute Node Template found";
                    Return $false;
                }

                Return $true;
            }

            DependsOn = "[Script]ConfigureHeadNode"
        }
    }
}

function Format-DscScriptBlock()
{
    param(
        [Parameter(Mandatory=$True)][System.Collections.HashTable]$Data,
        [Parameter(Mandatory=$True)][System.Management.Automation.ScriptBlock]$ScriptBlock
    )
    
    $Result = $ScriptBlock.ToString();
    foreach ($Key in $Data.Keys)
    {
        $Result = $Result.Replace("{$Key}", $Data[$Key]);
    }
    return $Result;
}
